create definer = root@localhost trigger user_table_AFTER_INSERT
    after insert
    on user_table
    for each row
BEGIN
	insert into user_info (user_id) values (NEW.user_id);
END;

