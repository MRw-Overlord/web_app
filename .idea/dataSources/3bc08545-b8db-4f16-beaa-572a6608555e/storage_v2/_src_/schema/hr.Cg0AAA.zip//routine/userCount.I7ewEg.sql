create
    definer = root@localhost procedure userCount(OUT cnt int)
BEGIN
    SELECT COUNT(*) INTO cnt FROM users;
end;

